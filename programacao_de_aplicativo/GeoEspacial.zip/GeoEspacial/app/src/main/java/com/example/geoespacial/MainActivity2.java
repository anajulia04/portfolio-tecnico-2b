package com.example.geoespacial;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {
    static int formula;
    EditText editText1, editText2, editText3;
    TextView r;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        getSupportActionBar().hide();
        editText1 = findViewById(R.id.editText1);
        editText2 = findViewById(R.id.editText2);
        editText3 = findViewById(R.id.editText3);
        r = findViewById(R.id.resultado);
        organizaTela();
    }

    public void organizaTela() {
        if (formula == 1) {
            editText1.setHint("Digite a área da base.");
            editText2.setHint("Digite o número dos lados.");
            editText3.setHint("Digite a área da face lateral.");
        } else if (formula == 7) {
            editText1.setHint("Volume");
            editText2.setHint("Area da base");
            editText3.setVisibility(View.INVISIBLE);
        } else if (formula == 2) {
            editText1.setHint("Area total");
            editText2.setHint("número de faces laterais");
            editText3.setHint("area das faces laterais");
        } else if (formula == 3) {
            editText1.setHint("Volume");
            editText2.setHint("altura");
            editText3.setVisibility(View.INVISIBLE);
        } else if (formula == 4) {
            editText1.setHint("Area total");
            editText2.setHint("area da base");
            editText3.setHint("area da face lateral");
        } else if (formula == 5) {
            editText1.setHint("Area total");
            editText2.setHint("area da base");
            editText3.setHint("numero da face lateral");
        } else if (formula == 6) {
            editText1.setHint("Area da base");
            editText2.setHint("altura");
            editText3.setVisibility(View.INVISIBLE);
        }
    }
    //sem o 3, 6, 7//
    public void mabel(View view){
        double conta;
        double a = Double.parseDouble(editText1.getText().toString());
        double b = Double.parseDouble(editText2.getText().toString());

        switch (formula){
            case 1:
                double c = Double.parseDouble(editText3.getText().toString());
                conta = 2*a + b*c;
                r.setText(conta+"");
                break;

            case 2:
                 c = Double.parseDouble(editText3.getText().toString());
                conta = a-b*c/2;
                r.setText(conta+"");
                break;

            case 4:
                 c = Double.parseDouble(editText3.getText().toString());
                conta = a - 2*b/c;
                r.setText(conta+"");
                break;

            case 5:
                c = Double.parseDouble(editText3.getText().toString());
                conta = a - 2*b/c;
                r.setText(conta+"");
                break;

              case 3:
                conta = a/b;
                  r.setText(conta+"");
                  break;

            case 6:
                conta = a*b;
                r.setText(conta+"");
                break;

            case 7:
                conta = a/b;
                r.setText(conta+"");
                break;

        }
    }
}