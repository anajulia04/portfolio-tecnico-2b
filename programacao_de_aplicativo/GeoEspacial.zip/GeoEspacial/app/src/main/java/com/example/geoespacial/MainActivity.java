package com.example.geoespacial;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    RadioButton AT, ABa, ABv, numL, AF, V, h;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        AT = findViewById(R.id.AT);
        ABa = findViewById(R.id.ABa);
        ABv = findViewById(R.id.ABv);
        numL = findViewById(R.id.numL);
        AF = findViewById(R.id.AF);
        V = findViewById(R.id.V);
        h = findViewById(R.id.h);
    }
    public void click(View view){
        Intent i = new Intent(this, MainActivity2.class);
        if (AT.isChecked()){
            MainActivity2.formula = 1;//
            startActivity(i);
        }
        else if (ABa.isChecked()){
            MainActivity2.formula = 2;
            startActivity(i);
        }
        else if (ABv.isChecked()){
            MainActivity2.formula = 3;
            startActivity(i);
        }
        else if (numL.isChecked()){
            MainActivity2.formula = 4;
            startActivity(i);
        }
        else if (AF.isChecked()){
            MainActivity2.formula = 5;
            startActivity(i);
        }
        else if (V.isChecked()){
            MainActivity2.formula = 6;
            startActivity(i);
        }
        else if (h.isChecked()){
            MainActivity2.formula = 7;
            startActivity(i);
        }
        else{
            Toast.makeText(this, "selecione uma opção",Toast.LENGTH_LONG ).show();

        }

    }
}